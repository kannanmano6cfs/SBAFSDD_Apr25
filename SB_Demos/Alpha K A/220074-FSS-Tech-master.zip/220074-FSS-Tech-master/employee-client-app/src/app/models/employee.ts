export interface Employee {
    id?:number,
    empName: string,
    empEmail: string,
    empSalary: number
}
