import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  private empApiUrl = environment.apiBaseUrl+'/employees'

  constructor(private http: HttpClient) { }

  getAllEmployees():Observable<Employee[]>{
    return this.http.get<Employee[]>(this.empApiUrl)
  }

  createEmployee(employee: Employee): Observable<Employee>{
    return this.http.post<Employee>(this.empApiUrl, employee);
  }

  getEmployeeById(id: number): Observable<Employee>{
    return this.http.get<Employee>(`${this.empApiUrl}/${id}`)
  }

  updateEmployee(employee: Employee):Observable<Employee>{
    return this.http.put<Employee>(`${this.empApiUrl}/${employee.id}`, employee)
  }

  deleteEmployeeById(id: number): Observable<any>{
    return this.http.delete<any>(`${this.empApiUrl}/${id}`)
  }
}
