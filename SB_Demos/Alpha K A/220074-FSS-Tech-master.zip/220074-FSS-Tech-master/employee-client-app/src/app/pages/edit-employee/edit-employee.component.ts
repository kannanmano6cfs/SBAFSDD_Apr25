import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { EmployeesService } from '../../services/employees.service';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-edit-employee',
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './edit-employee.component.html',
  styleUrl: './edit-employee.component.css'
})
export class EditEmployeeComponent {
  employeeForm = new FormGroup({
    empName: new FormControl('',[Validators.required, Validators.minLength(3)]),
    empEmail: new FormControl('', [Validators.required, Validators.email]),
    empSalary: new FormControl('', [Validators.required, Validators.min(1)])
  })
  id:number=0;

  constructor(private employeeService: EmployeesService, private route: ActivatedRoute){
    this.id = this.route.snapshot.params['id'];
    this.employeeService.getEmployeeById(this.id).subscribe(data=>{
      this.employeeForm.patchValue({
        empName:data.empName,
        empEmail: data.empEmail,
        empSalary: String(data.empSalary)
      })
    })
  }

  getFormControl(controlName: string): FormControl {
    return this.employeeForm.get(controlName) as FormControl;
  }

  successMessage: string =''
  errorMessage: string = ''

  handleSubmit(){
    this.successMessage =''
    this.errorMessage =''
    const {empName, empEmail, empSalary} = this.employeeForm.value;
    if(empName && empEmail && empSalary){
      const updatedEmployee: Employee = {id:this.id,empName, empEmail , empSalary: Number(empSalary)}
      this.employeeService.updateEmployee(updatedEmployee).subscribe({
        next: (data)=> {
          if(data){
            this.successMessage = 'Employee updated successfully'
          }
        },
        error: (error) =>{
          console.log(error)
          this.errorMessage = "Something went wrong, please try again"
        }
      })
    }
  }
}
