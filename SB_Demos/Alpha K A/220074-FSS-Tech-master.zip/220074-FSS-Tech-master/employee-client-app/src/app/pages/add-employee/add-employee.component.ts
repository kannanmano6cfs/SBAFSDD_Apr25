import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmployeesService } from '../../services/employees.service';
import { Employee } from '../../models/employee';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent {
  employeeForm = new FormGroup({
    empName: new FormControl('',[Validators.required, Validators.minLength(3)]),
    empEmail: new FormControl('', [Validators.required, Validators.email]),
    empSalary: new FormControl('', [Validators.required, Validators.min(1)])
  })

  constructor(private employeeService: EmployeesService){

  }

  getFormControl(controlName: string): FormControl {
    return this.employeeForm.get(controlName) as FormControl;
  }

  successMessage: string =''
  errorMessage: string = ''

  handleSubmit(){
    this.successMessage =''
    this.errorMessage =''
    const {empName, empEmail, empSalary} = this.employeeForm.value;
    if(empName && empEmail && empSalary){
      const newEmployee: Employee = {empName, empEmail , empSalary: Number(empSalary)}
      this.employeeService.createEmployee(newEmployee).subscribe({
        next: (data)=> {
          if(data){
            this.employeeForm.reset()
            this.successMessage = 'Employee added successfully'
          }
        },
        error: (error) =>{
          console.log(error)
          this.errorMessage = "Something went wrong, please try again"
        }
      })
    }
  }
}
