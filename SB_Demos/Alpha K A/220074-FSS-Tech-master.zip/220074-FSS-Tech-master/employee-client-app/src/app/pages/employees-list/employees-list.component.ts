import { Component } from '@angular/core';
import { Employee } from '../../models/employee';
import { EmployeesService } from '../../services/employees.service';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-employees-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './employees-list.component.html',
  styleUrl: './employees-list.component.css'
})
export class EmployeesListComponent {
  employees: Employee[] =[]
  constructor(private employeeService: EmployeesService){
    this.loadAllEmployees()
  }

  loadAllEmployees(){
    this.employeeService.getAllEmployees().subscribe((data)=>{
      this.employees = data;
      // console.log(data)
    })
  }

  hanldeDelete(id: number){
    const result = confirm("Are you sure, do you want to delete the employee?")
    if(result){
      this.employeeService.deleteEmployeeById(id).subscribe({
        next: ()=>{
          this.loadAllEmployees()
        },
        error: (error)=>{
          console.log(error)
        }
      })
    }
  }
}
