export const environment = {
    apiBaseUrl: "https://employee-api-hfbkctfzdqd4esca.centralindia-01.azurewebsites.net/api"
};
